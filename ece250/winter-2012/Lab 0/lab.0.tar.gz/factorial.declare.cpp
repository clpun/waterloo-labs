/*************************************************
 * factFunction2.cpp
 * 
 *
 * Calculates the factorial of a given number using a function
 *
 * Function declaration is separated from function definition.
 * 
 *************************************************/

#include <iostream>
using namespace std;



// Function declaration - before the function is used

int factorial( int n );
    

int main ()
{
  int n = 5 ;
  int nFact ;

  nFact = factorial(n) ;
  
  cout << "the factorial of " <<  n << " is " << nFact << endl;
  return 0;
}


int factorial( int n ) {
if ( n == 0 ) {
        return 1;
    } else {
        return n*factorial( n - 1 );
    }
}





