/*************************************************
 * pass_by_reference.cpp
 * 
 * A function passign parameters by reference.
 * If the value of the argument is changed in the function, 
 * the value of the corresponding parameter changes in the 
 * calling function.
 *************************************************/

#include <iostream>
using namespace std;

void f( int & n ) {
	cout << "Inside f( int & ), the value of the parameter is " << n << endl;

	n += 37;            // change value of n will change the value of m in the calling program

	cout << "Inside f( int & ), the modified parameter is now " << n << endl;

	return;
}

int main() {
	int m = 612;

	cout << "The integer m = " << m << endl;

	cout << "Calling f( m )..." << endl;

	f( m );

	cout << "After f(m) is called the value of the  integer m = " << m << endl; 

	return 0;
}
