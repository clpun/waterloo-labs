/*************************************************
 * DataTypes.cpp
 * Declaration, initialization, printing, memory 
 * used by common built-in data types
 *  
 * Author:  Tiuley Alguindigue
 * 
 *************************************************/


#include <iostream>
using namespace std;

int main() {

	/* declaring and initializing variables */

    int counter = 0 ;
	double average = 0.0 ;
	bool aproved = false ;
	char startCharacter = 'A' ;

	/* a constant */
	const double PI = 3.1416 ;

	/* assigning values */

	counter  = 5;
	aproved = false ;

	/* printing values */

	cout << "counter : " << counter << endl ; // printing count and starting a new line with endl
	cout << "aproved : " << aproved << endl ; 
	


	/* Show size(number of bytes) that this type occupies in memory */

	cout << " size of integer " << sizeof(counter) << endl;
	cout << " size of double " << sizeof(average) << endl;
	cout << " size of booleam " << sizeof(aproved) << endl;	
	cout << " size of char " << sizeof(startCharacter) << endl;

   
}

