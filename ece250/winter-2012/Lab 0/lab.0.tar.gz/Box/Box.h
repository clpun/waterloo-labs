#ifndef BOX_H
#define BOX_H

/*****************************************
 * UW User ID:  XXXXXXXX
 * Submitted for ECE 250
 * Department of Electrical and Computer Engineering
 * University of Waterloo
 * Calender Term of Submission:  (Winter|Spring|Fall) 20NN
 *
 * By submitting this file,  I affirm that
 * I am the author of all modifications to
 * the provided code.
 *****************************************/

#include "ece250.h"
#include "Exception.h"

template <typename Object>
class Box {
	private:
		Object element;

	public:
		Box();

		// copy constructor and assignment operator
		Box( const Box & );
		Box &operator = ( const Box & );

		// Accessors
		Object get() const;

		// Mutators
		void set( const Object & );
};

// Object() creates a default instance of the type
// e.g., the default int and double are both 0
template <typename Object>
Box<Object>::Box():element( Object() ) {
	// empty constructor
}

// This simply calls operator=
template <typename Object>
Box<Object>::Box( const Box<Object> &box ) {
	*this = box;
}

template <typename Object>
Box<Object> &Box<Object>::operator = ( const Box<Object> & rhs ) {
	if ( &rhs == this ) {
		return *this;
	}

	element = rhs.element;
	return *this;
}

template <typename Object>
Object Box<Object>::get() const {
	return element;
}

template <typename Object>
void Box<Object>::set( const Object & e ) {
	element = e;
}

#endif
