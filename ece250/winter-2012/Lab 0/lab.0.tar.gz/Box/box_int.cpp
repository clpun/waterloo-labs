#include <iostream>
using namespace std;

#include "Box.h"

int main() {
	Box<int> a_box;
  
  cout << "The default value stored in 'a_box' is  " << a_box.get() << endl;
	
  a_box.set( 3 );

	cout << "The value in a_box is now " << a_box.get() << endl;

	a_box.set( 4 );

	cout << "The value in a_box is now " << a_box.get() << endl;

	Box<int> b_box;

  cout << "The default value stored in 'b_box' is  " << b_box.get() << endl;

	b_box.set( 9 );

	cout << "The value in b_box is now " << b_box.get() << endl;

	a_box = b_box;

  cout << "Assigning a_box = b_box" << endl;
	cout << "The value in a_box is now " << a_box.get() << endl;

	// No need to test the copy constructor explicitly...
	// It just calls the operator=

	return 0;
}
