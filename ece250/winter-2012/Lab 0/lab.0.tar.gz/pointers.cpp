/*************************************************
 * addresses.cpp
 * Shows how variables of type integer and double are stored in memory
 *
 *  
 * Author:  Tiuley Alguindigue
 * 
 *************************************************/


#include <iostream>
using namespace std;

int main() {

	/* declaring and initializing variables */

        int counter = 1 ;
        int *ptr ; // ptr is the address of an int, or a pointer to an int

        ptr = &counter;

        cout << "The variable ptr = " << ptr << endl;
        cout << "The value at that address is *ptr = " << *ptr << endl;

        cout << "Updating the value stored at ptr..." << endl;
         *ptr = 2;

        cout << "The variable ptr  is unchanged: ptr = " << ptr << endl;
        cout << "The value at that address is *ptr =  " << *ptr << endl;
        cout << "The original value is also changed: counter ="    << counter << endl;
   
}
