#include <iostream>
using namespace std;

int main() {
    

    
	int *ptr = 0;         // pointing to nothing
        cout << "The pointer is initially pointing to 0:  " << ptr << endl;
 

	ptr = new int( 42 );   // ask for new memory from the OS, initialze with value 42

	cout << "The pointer storing the address " << ptr << endl;
	cout << "The value stored there is " << *ptr << endl;

	*ptr = 256;

	cout << "The pointer is still storing the address " << ptr << endl;
	cout << "The value stored there is now " << *ptr << endl;

	delete ptr;            // give the memory back to the OS
	ptr = 0;               // set the pointer to 0

	return 0;
}


