Build instructions: 
1. In terminal, type in "gcc -g -lrt -Wall lab1.c -o lab1.o".
2. Run program by typing in "./lab1.o".

Sample Output: 

32 is consumed.
11 is consumed.
15 is consumed.
5 is consumed.
38 is consumed.
40 is consumed.
24 is consumed.
5 is consumed.
4 is consumed.
16 is consumed.
21 is consumed.
8 is consumed.
23 is consumed.
5 is consumed.
40 is consumed.
41 is consumed.
22 is consumed.
27 is consumed.
5 is consumed.
3 is consumed.
time to initialize system: 0.000527 seconds
time to transimit data: 0.001945 seconds