Linux Build Instructions: 

- Files are in Linux folder.

lab2_1.c(Message queue approach):
1. Type "gcc -g -lrt -lm -Wall lab2_1.c -o lab2_1.o" to build.
2. Type "./lab2_1.o" to run. 


lab2_2.c(Shared memory approach):
1. Type "gcc -g -lrt -lm -Wall lab2_2.c -o lab2_2.o" to build.
2. Type "./lab2_2.o" to run. 

Keil Important Notes: 
- Projects are in Keil folder.
- lab2_1 project uses mailbox approach.
- lab2_2 project uses shared memory approach.